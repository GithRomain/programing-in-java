import java.util.LinkedList;
import java.util.List;

public interface Operation {
    public int doOperation();
    public int getLastRes();
    public String getName();
}
